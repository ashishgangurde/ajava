package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Vendor;
import com.app.service.IVendorService;

@Controller
@RequestMapping("/user")
public class UserController 
{
	public UserController()
	{
		System.out.println("In constructor of"+getClass().getName());
	}
	
	@Autowired
	private IVendorService service;
	
	//to show login form
	@GetMapping("/login")
	public String ShowLoginForm()
	{
		System.out.println("In Show Login Form");
		return "/user/login";
	}
	
	//to process login form
	@PostMapping("/login")
	public String ProcessLoginForm(Model map,
			@RequestParam String email,
			@RequestParam String password,HttpSession hs)
	{
		System.out.println("In Process Login Form");
		try
		{
			Vendor v=service.validateUser(email, password);
			//if login successfull
			map.addAttribute("status", "Login Successfull");
			
			//to remember user put user details into session
			hs.setAttribute("user_dtls", v);	
			
			if(v.getRole().equals("admin"))
			{
				return "redirect:/admin/list";
			}
			//after successfull login go to details
			return "/vendor/details";
		}
		catch (RuntimeException e) 
		{
			System.out.println("Error in User Controller"+e);
			//if invalid login
			return "/user/login";
		}
	}
	
	@GetMapping("/logout")
	public String userLogout(Model map,
			HttpSession hs, 
			HttpServletRequest request,
			HttpServletResponse response)
	{
		System.out.println("In user LogOut");
		map.addAttribute("dtls", hs.getAttribute("user_dtls"));
		
		//discard session
		hs.invalidate();
		
		response.setHeader("refresh", "5;url="+request.getContextPath());
		return "/user/logout";
	}
}







package com.app.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Vendor;
import com.app.service.IVendorService;

@Controller
@RequestMapping("/admin")
public class AdminController
{
	@Autowired
	private IVendorService service;
	
	public AdminController()
	{
		System.out.println("In constructor of"+getClass().getName());
	}
	
	@GetMapping("/list")
	public String showVendorList(Model map)
	{
		System.out.println("In Admin list vendor");
		
		map.addAttribute("vendor_list", service.listVendors());
		return "/admin/list";
	}
	
	@GetMapping("/delete")
	public String deleteVendor(HttpSession hs,HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam int vid)
	{
		System.out.println("In Admin delete vendor");
		hs.setAttribute("vendor_list", service.deleteVendor(vid));
		return "redirect:/admin/list";
		//response.setHeader("refresh", "3;url"+request.getContextPath());
		//return "/admin/delete";
	}
	
	@GetMapping("/update")
	public String updateVendor()
	{
		System.out.println("In update Form");
		return "/admin/update";
	}
	
	@PostMapping("/update")
	public String updateVendor(HttpSession hs,HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam int vid,
			@RequestParam String city,
			@RequestParam String phoneNo)
	{
		System.out.println("In Admin update vendor");
		hs.setAttribute("vendor_list", service.updateVendor(vid,city,phoneNo));
		return "redirect:/admin/list";
	}
	
	@GetMapping("/add")
	public String showRegisterForm()
	{
		System.out.println("In Show Register Form");
		return "/admin/add";
	}
	
	@PostMapping("/add")
	public String processRegisterForm(Model map,
			@RequestParam String name,
			@RequestParam String email,
			@RequestParam String password,
			@RequestParam String role,
			@RequestParam String city,
			@RequestParam String phoneNo,
			@RequestParam double regAmount,
			@RequestParam @DateTimeFormat(pattern="yyyy-MM-dd") Date regDate,HttpSession hs)
	{
		System.out.println("In Process Register Form");
		Vendor v=new Vendor(name, email, password, role, city, phoneNo, regAmount, regDate);
		hs.setAttribute("vendor_list", v);
		map.addAttribute("vendor_list", service.addVendor(v));
		return "redirect:/admin/list";
	}
}











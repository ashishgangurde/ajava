package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IVendorDao;
import com.app.pojos.Vendor;

@Service //to tell SC whatever class follows has BL method
@Transactional //to automate transaction management
public class VendorServiceImpl implements IVendorService {
	
	@Autowired	//dependancy injection	//byType
	private IVendorDao dao;
	
	@Override
	public Vendor validateUser(String email, String pass)
	{
		return dao.validateUser(email, pass);
	}

	@Override
	public List<Vendor> listVendors()
	{
		return dao.listVendors();
	}

	@Override
	public String deleteVendor(int vid) 
	{
		return dao.deleteVendor(vid);
	}

	@Override
	public String updateVendor(int vid,String city,String phoneNo) 
	{
		return dao.updateVendor(vid,city,phoneNo);
	}

	@Override
	public String addVendor(Vendor v)
	{
		return dao.addVendor(v);
	}
	

}

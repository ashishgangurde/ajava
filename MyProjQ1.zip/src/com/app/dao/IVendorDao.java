package com.app.dao;

import java.util.List;

import com.app.pojos.Vendor;

public interface IVendorDao 
{
	Vendor validateUser(String email,String pass);
	List<Vendor> listVendors();
	String addVendor(Vendor v);
	String deleteVendor(int vid);
	String updateVendor(int vid,String city,String phoneNo);
}

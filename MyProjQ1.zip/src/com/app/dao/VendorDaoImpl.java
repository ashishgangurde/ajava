package com.app.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Vendor;

import java.util.List;

import org.hibernate.*;

@Repository
public class VendorDaoImpl implements IVendorDao
{
	@Autowired	//dependancy injection	//byType
	private SessionFactory sf;
	
	public VendorDaoImpl() 
	{
		System.out.println("In Constructor of"+getClass().getName());
	}
	
	@Override
	public Vendor validateUser(String email, String pass)
	{
		String jpql="select v from Vendor v where v.email=:em and v.password=:pa";
		return sf.getCurrentSession().createQuery(jpql,Vendor.class).
				setParameter("em", email).setParameter("pa", pass).getSingleResult();
	}

	@Override
	public List<Vendor> listVendors() 
	{
		String jpql="select v from Vendor v where v.role=:role";
		return sf.getCurrentSession().
				createQuery(jpql, Vendor.class).
				setParameter("role", "vendor").getResultList();
	}

	@Override
	public String deleteVendor(int vid) 
	{
		String msg="Vendor Deletion Unsuccessful...";
		
		Vendor v=sf.getCurrentSession().get(Vendor.class, vid);
		sf.getCurrentSession().delete(v);
		msg="Vendor Deletion Successful...";
		
		return msg;
	}

	@Override
	public String updateVendor(int vid, String city,String phoneNo) 
	{
		String msg="Vendor Updation Unsuccessful...";
		
		sf.getCurrentSession().get(Vendor.class, vid).setCity(city);
		sf.getCurrentSession().get(Vendor.class, vid).setPhoneNo(phoneNo);
		msg="Vendor Updation Successful...";
		
		return msg;
	}

	@Override
	public String addVendor(Vendor v) 
	{
		String msg="Vendor Registration Unsuccessful...";
		
		sf.getCurrentSession().save(v);
		msg="Vendor Registration Successful...";
		return msg;
	}
	
	

}
